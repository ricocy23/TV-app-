﻿using System.Windows.Controls;

namespace Tv_App.Pages
{
    public partial class Time_Page : UserControl
    {
        public Time_Page()
        {
            InitializeComponent();
        }
    }
}