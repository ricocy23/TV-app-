﻿using System.Windows.Controls;

namespace Tv_App.Pages
{
    public partial class Storage_Page : UserControl
    {
        public Storage_Page()
        {
            InitializeComponent();
        }
    }
}