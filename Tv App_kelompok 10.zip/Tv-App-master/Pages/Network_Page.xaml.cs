﻿using System.Windows.Controls;

namespace Tv_App.Pages
{
    public partial class Network_Page : UserControl
    {
        public Network_Page()
        {
            InitializeComponent();
        }
    }
}