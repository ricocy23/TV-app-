﻿using System.Windows.Controls;

namespace Tv_App.Pages
{
    public partial class About_Page : UserControl
    {
        public About_Page()
        {
            InitializeComponent();
        }
    }
}